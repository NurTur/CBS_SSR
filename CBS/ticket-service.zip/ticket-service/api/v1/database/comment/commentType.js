`use strict`;

const commentTypeValues = {
    engineer   : `0`,
    coordinator: `1`,
    announce   : `2`,
    service    : `3`
};
module.exports = commentTypeValues;