module.exports = {
	NO_REQ_PARAMS: `Отсутствует обязательный параметр ticketId.`,
	NO_MANAGER_FOUND: (ticketId) => `Менеджер по заявке №${ticketId} не найден.`
}
